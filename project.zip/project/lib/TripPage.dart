import 'package:flutter/material.dart';


class TripPage extends StatelessWidget {
  const TripPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text("Trip Page",style: TextStyle(fontSize: 20.0))
        ,
      ),
    );
  }
}
