class userClass{

  String email;
  String id;
  String name;
  String surname;
  String gender;
  String age;


  userClass({this.id, this.name, this.surname, this.gender, this.email, this.age,});
}