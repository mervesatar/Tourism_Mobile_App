import 'package:flutter/material.dart';


class ERPage extends StatelessWidget {
  const ERPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text("ER Page",style: TextStyle(fontSize: 20.0))
        ,
      ),
    );
  }
}
